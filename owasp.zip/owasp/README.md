# Taller OWASP Top 10 — Tienda vulnerable (Spring Boot)

Tienda de ejemplo con Spring Boot **intencionalmente vulnerable** (`vulnerable`, puerto 3000) más un **sitio atacante** (`evil`, puerto 4000), para un taller sobre seis vulnerabilidades del OWASP Top 10. En cada módulo se lanza el ataque contra la tienda y se observa el resultado en el navegador (DevTools), en los archivos `.http` o en el marcador `/dashboard`.

Java 21 · Spring Boot 3.4.2 · Spring Data JPA (H2 en memoria) · Spring Security.

## Aviso ético

Este proyecto tiene fines **educativos**: demuestra vulnerabilidades reales. Las técnicas aquí mostradas solo deben aplicarse al **entorno local de este proyecto** o a sistemas con **autorización expresa y por escrito**. No se deben usar contra sistemas reales sin permiso.

## Instalación y ejecución

### Requisitos

- **Java 21** (Temurin recomendado).
- **VS Code** con la extensión *REST Client* (`humao.rest-client`) para los `.http`.
- **Google Chrome** normal (no incógnito): M4 y M5 dependen de cómo Chrome trata las cookies.
- Maven Wrapper (`mvnw.cmd`) ya viene en el proyecto; no hay que instalar Maven.

### Verificar el entorno

```powershell
.\scripts\check.bat
```

`check.bat` comprueba Java 21 y los puertos 3000/4000 e imprime `Listo para el taller`. Para correr las pruebas: `.\mvnw.cmd clean test`.

### Levantar los perfiles (una terminal por perfil)

```powershell
.\mvnw.cmd spring-boot:run "-Dspring-boot.run.profiles=vulnerable"
```

```powershell
.\mvnw.cmd spring-boot:run "-Dspring-boot.run.profiles=evil"
```

La base H2 es en memoria y se **rellena sola al arrancar**: reiniciar el servidor restaura la base. Usuarios de prueba: `admin/admin123`, `maria/sunshine`, `juan/qwerty2024`.

## Perfiles, puertos y cookies

| Perfil | Puerto | Cookie de sesión | Frontend | Notas de cookie |
|---|---|---|---|---|
| `vulnerable` | 3000 | `sid_vuln` | `static-vulnerable/` | `SameSite=None; Secure`, `HttpOnly=false` (a propósito) |
| `evil` | 4000 | — | `static-evil/` | sitio atacante; sin `Seed` |

La tienda vive en `localhost` y el atacante en `127.0.0.1:4000`, para que Chrome los trate como **sitios distintos** (clave para M4 y M5). Todo escucha solo en `127.0.0.1`.

## Módulos

| Módulo | Vulnerabilidad | Material |
|---|---|---|
| **M1** | Inyección SQL | `requests/01-sqli.http` |
| **M2** | Datos sensibles | `requests/02-datos-sensibles.http` |
| **M3** | XSS almacenado | `requests/03-xss.http` |
| **M4** | CORS y cabeceras HTTP | por navegador (`http://127.0.0.1:4000`) |
| **M5** | CSRF | por navegador (`http://127.0.0.1:4000/premio.html`) |
| **M6** | Fuerza bruta | `attacks/DictionaryAttack` |
| Extra | IDOR (opcional) | `requests/07-idor.http` |

### M1 — Inyección SQL

Hibernate parametriza por defecto; para la lección, la tienda arma a propósito una consulta nativa concatenando el texto del usuario. `POST /api/login` y `GET /api/products?q=` pegan la entrada en el SQL y devuelven el error de la base al cliente.

- `admin' --` como usuario (cualquier contraseña) → entra como admin.
- `'` en el buscador → error de SQL visible.
- `' UNION SELECT id, username, password, 0 FROM users --` → usuarios y contraseñas en la lista de productos.
- **Cuidado:** los payloads no deben llevar `:` ni `?` (Hibernate los toma como parámetros).

### M2 — Datos sensibles

Las contraseñas se guardan en claro y un login válido responde con la **entidad `User` completa** (incluye `password`). Visible también en la consola H2 (`http://localhost:3000/h2-console`, JDBC `jdbc:h2:mem:tienda`, `sa` sin contraseña).

### M3 — XSS almacenado

Los comentarios se guardan sin filtrar y el frontend los pinta con `innerHTML`. `<img src=x onerror=alert(document.cookie)>` muestra la cookie `sid_vuln` (legible porque no es `HttpOnly`). No hay cabecera `Content-Security-Policy`.

### M4 — CORS y cabeceras HTTP

CORS permisivo (`allowedOriginPatterns("*")` + `allowCredentials(true)`) y cabeceras de seguridad apagadas (`headers.disable()`). El sitio atacante (`127.0.0.1:4000`) lee con `fetch(..., { credentials: "include" })` el perfil y los comentarios de la víctima.

### M5 — CSRF (cambio de correo)

`POST /api/account/email` solo comprueba la sesión; sin token CSRF y con la cookie `SameSite=None`, el formulario oculto de `premio.html` cambia el correo de la víctima desde otro sitio.

### M6 — Fuerza bruta

Sin límite de intentos; un ataque de diccionario (`attacks/DictionaryAttack`, con `src/main/resources/attacks/passwords.txt`) prueba contraseñas hasta acertar.

### Extra — IDOR (opcional)

`GET /api/users/{id}`: cualquier usuario con sesión lee los datos de otro cambiando el número de la URL.

### Reto CTF (tarea para la casa)

La base tiene una tabla `secreto_ctf` que ninguna pantalla muestra. El reto es leer su bandera con la inyección SQL del buscador. **Pista:** `INFORMATION_SCHEMA` (H2 no tiene `sqlite_master`). Solución en `soluciones/00-ctf.md`.

## Marcador y `/dashboard`

Los controladores y filtros llaman a `Scoreboard.registrar(modulo, ataque, resultado)` **solo cuando hay un ataque** (payload, petición cross-site, exceso de intentos), así que el uso normal de la tienda no ensucia el marcador. Cada llamada agrega una línea a `scoreboard.jsonl`; `GET http://localhost:3000/dashboard` muestra los ataques que tuvieron éxito.

| Módulo | Ataque |
|---|---|
| `M1` | `Login sin contraseña (admin' --)` / `Error SQL visible (comilla)` / `UNION SELECT a users` / `Reto CTF (secreto_ctf)` |
| `M2` | `Contraseña expuesta en el login` |
| `M3` | `XSS almacenado (<img onerror>)` |
| `M4` | `Lectura de datos desde otro sitio (CORS)` |
| `M5` | `Cambio de correo sin consentimiento (CSRF)` |
| `M6` | `Fuerza bruta al login (sin límite)` |
| `IDOR` | `Leer el perfil de otro usuario` |

### Nota sobre `SameSite`

La tienda fuerza `SameSite=None` **a propósito**: los navegadores actuales ya usan `SameSite=Lax` por defecto, que por sí solo mitigaría buena parte de CSRF. Chrome solo acepta `SameSite=None` si la cookie es `Secure`; en `localhost`/`127.0.0.1` lo trata como contexto seguro, por eso funciona sin HTTPS en la demo.

## Estructura del proyecto

- `vulnerable/`, `evil/`: controladores y configuración por perfil (`@Profile`).
- `shared/`: componentes comunes (`Seed`, `Scoreboard`, `DashboardController`, sesión, etiquetas del marcador).
- `domain/`, `repository/`, `service/`: entidades JPA, repositorios y servicios.
- `attacks/`: `DictionaryAttack` (M6).
- `requests/`: peticiones `.http` (REST Client) por módulo.
- `soluciones/`: solución del reto CTF.
- `scripts/`: `check.bat`.
