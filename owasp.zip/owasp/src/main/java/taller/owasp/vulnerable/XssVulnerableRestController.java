package taller.owasp.vulnerable;

import java.util.List;

import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import taller.owasp.domain.Comment;
import taller.owasp.service.CommentService;
import taller.owasp.shared.Scoreboard;

import static taller.owasp.shared.AtaquesInyeccion.*;

// Ejercicio 3: los comentarios se guardan sin filtrar (XSS almacenado).
@RestController
@Profile("vulnerable")
@RequestMapping("/api/comments")
public class XssVulnerableRestController {

    private final CommentService commentService;

    public XssVulnerableRestController(CommentService commentService) {
        this.commentService = commentService;
    }

    /**
     * El método GET lista los comentarios existentes de forma descendente
     */
    @GetMapping
    public List<Comment> listar() {
        return commentService.findAllByOrderByIdDesc();
    }

    /**
     * =========================================================================
     * Ejercicio 3. Comentarios
     * =========================================================================
     * Gestiona la creación y el listado de comentarios de los usuarios. El método POST 
     * recibe un autor y un contenido para guardarlos en el sistema.
     * 
     * ATENCIÓN (Vulnerabilidad de XSS Almacenado):
     * Este código procesa y almacena los datos enviados en el cuerpo de la petición 
     * directamente sin realizar ningún tipo de filtrado o sanitización:
     *     commentService.guardar(datos.author(), datos.content())
     * 
     * ¿Por qué es peligroso?
     * Al no depurar la entrada, un atacante puede inyectar scripts maliciosos o 
     * etiquetas HTML (como <script>) que se guardarán de forma persistente en la 
     * base de datos. Cada vez que otro usuario cargue la página, el navegador 
     * ejecutará dicho código, permitiendo robar sesiones o comprometer cuentas.
     * 
     * Reto: Refactoriza el método POST validando los límites de longitud del texto 
     * e implementando un mecanismo de sanitización para limpiar de forma segura el 
     * contenido antes de guardarlo.
     */
    @PostMapping
    public Comment crear(@RequestBody ComentarioRequest datos) {
        Comment guardado = commentService.guardar(datos.author(), datos.content());
        if (esXss(datos.content()) || esXss(datos.author())) {
            Scoreboard.registrar(M3, M3_XSS, EXITO);
        }
        return guardado;
    }

    /**
     * Implemente su solución aquí
     */
    


    public record ComentarioRequest(String author, String content) {}
}
