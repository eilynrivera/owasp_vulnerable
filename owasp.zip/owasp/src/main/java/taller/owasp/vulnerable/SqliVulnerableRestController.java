package taller.owasp.vulnerable;

import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpSession;
import taller.owasp.domain.User;
import taller.owasp.service.ProductService;
import taller.owasp.service.UserService;
import taller.owasp.shared.Scoreboard;
import taller.owasp.shared.SessionUser;

import static taller.owasp.shared.AtaquesInyeccion.*;
import static taller.owasp.shared.AtaquesTaller.*;

// Ejercicio 1: inyeccion SQL en el login y en la busqueda de productos.
// Ejercicio 2: el login responde con la entidad completa (contraseña incluida).
@RestController
@Profile("vulnerable")
@RequestMapping("/api")
public class SqliVulnerableRestController {

    private final UserService userService;
    private final ProductService productService;

    public SqliVulnerableRestController(UserService userService, ProductService productService) {
        this.userService = userService;
        this.productService = productService;
    }

    /**
     * =========================================================================
     * Ejercicio 1. Login
     * =========================================================================
     * Gestiona la autenticación de usuarios recibiendo las credenciales en formato 
     * JSON y el objeto de sesión HTTP. Verifica si el usuario existe, valida las 
     * credenciales ingresadas, crea una sesión activa en el servidor y devuelve 
     * la información del usuario si el acceso es correcto.
     * 
     * Reto:
     * Actualmente este método permite que las credenciales viajen de forma insegura 
     * y facilita la inyección SQL y el robo de sesiones. Debes corregirlo de modo que:
     *   1. Busques al usuario de forma segura utilizando una consulta basada en 
                el repositorio (ej. buscando únicamente por el nombre de usuario).
     *   2. Utilices un componente de codificación de contraseñas (como BCrypt o un 
                `PasswordEncoder`) para comparar de manera segura la contraseña 
                ingresada con el hash almacenado en la base de datos, en lugar de 
                comparar texto plano en la consulta SQL.
     *   3. Retornes un objeto de transferencia de datos (DTO) seguro que no exponga 
                información sensible (como la contraseña) y manejes adecuadamente 
                las excepciones de forma genérica.
     * =========================================================================
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest datos, HttpSession session) {
        try {
            List<User> usuarios = userService.loginInseguro(datos.username(), datos.password());
            if (usuarios.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("mensaje", "Credenciales incorrectas"));
            }
            User u = usuarios.get(0);
            session.setAttribute(SessionUser.ATRIBUTO_SESION,
                    new SessionUser(u.getId(), u.getUsername(), u.getRole()));
            if (esInyeccionSql(datos.username()) || esInyeccionSql(datos.password())) {
                Scoreboard.registrar(M1, M1_LOGIN, EXITO);
            }

            Scoreboard.registrar(M2, M2_PASSWORD, EXITO);

            return ResponseEntity.ok(u);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    /*
    * Implemente su solución aquí
    */

    /**
     * =========================================================================
     * Ejercicio 2. Buscar productos:
     * =========================================================================
     * Permite buscar productos en el catálogo a partir de un parámetro de texto 
     * opcional recibido en la URL. Devuelve una lista de los productos 
     * coincidentes en formato JSON para que el cliente pueda visualizarlos.
     * 
     * Reto:
     * El método original concatena el parámetro de búsqueda directamente en una 
     * sentencia SQL nativa, abriendo la puerta a ataques de Inyección SQL (SQLi). 
     * 
     * Debes refactorizar este método eliminando la concatenación manual y reemplazándola 
     * por las abstracciones nativas de Spring Data JPA (por ejemplo, utilizando un 
     * método de consulta derivado en el repositorio como `findBy...` o consultas 
     * parametrizadas). De esta forma, cualquier carácter especial o intento de 
     * ataque será tratado estrictamente como texto literal y la consulta se 
     * mantendrá segura.
     * =========================================================================
     */
    @GetMapping("/products")
    public ResponseEntity<?> buscar(@RequestParam(defaultValue = "") String q) {
        String ataque = ataqueDeBusqueda(q);
        try {
            List<Map<String, Object>> filas = productService.buscarInseguro(q);
            if ((M1_UNION.equals(ataque) || M1_CTF.equals(ataque)) && !filas.isEmpty()) {
                Scoreboard.registrar(M1, ataque, EXITO);
            }
            return ResponseEntity.ok(filas);
        } catch (Exception e) {
            if (ataque != null) {
                Scoreboard.registrar(M1, M1_COMILLA, EXITO);
            }

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    /**
     * Implemente su solución aquí
     */



    public record LoginRequest(String username, String password) {}
}
