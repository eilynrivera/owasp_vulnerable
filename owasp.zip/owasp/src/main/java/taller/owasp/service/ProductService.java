package taller.owasp.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import taller.owasp.domain.Product;
import taller.owasp.repository.ProductRepository;

@Service
@Transactional
public class ProductService {

    private final ProductRepository productRepository;
    private final EntityManager entityManager;

    public ProductService(ProductRepository productRepository, EntityManager entityManager) {
        this.productRepository = productRepository;
        this.entityManager = entityManager;
    }


    /**
     * Busca productos en la base de datos que coincidan parcialmente con el 
     * nombre ingresado, ignorando mayúsculas y minúsculas, usando ILIKE.
     * 
     * ATENCIÓN (Vulnerabilidad de Inyección SQL):
     * Este código concatena directamente el parámetro 'q' en la sentencia SQL:
     *     "WHERE name ILIKE '%" + q + "%'"
     * 
     * ¿Por qué es peligroso?
     * Al no utilizar parámetros seguros, un atacante puede ingresar comandos 
     * SQL maliciosos en lugar de texto plano, manipulando la consulta original 
     * para extraer, modificar o eliminar datos de la base de datos.
     * 
     * Reto: Refactoriza el método usando consultas parametrizadas para solucionarlo.
     */
    public List<Map<String, Object>> buscarInseguro(String q) {
        String sql = "SELECT id, name, description, price FROM products "
                   + "WHERE name ILIKE '%" + q + "%'";

        List<?> filas = entityManager.createNativeQuery(sql).getResultList();

        List<Map<String, Object>> productos = new ArrayList<>();
        for (Object fila : filas) {
            Object[] col = (Object[]) fila;
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("id", col[0]);
            p.put("name", col[1]);
            p.put("description", col[2]);
            p.put("price", col[3]);
            productos.add(p);
        }
        return productos;
    }

    /**
     * Implemente el método seguro aquí
     */
}
