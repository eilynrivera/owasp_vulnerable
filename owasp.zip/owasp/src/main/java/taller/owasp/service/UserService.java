package taller.owasp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import taller.owasp.domain.User;

@Service
@Transactional
public class UserService {
    private final EntityManager entityManager;

    public UserService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    /**
     * Busca un usuario en la base de datos comparando el nombre de usuario 
     * y la contraseña proporcionados.
     * 
     * ATENCIÓN (Vulnerabilidad de Inyección SQL):
     * Este código concatena directamente los parámetros en la sentencia SQL:
     *     "WHERE username = '" + username + "' AND password = '" + password + "'"
     * 
     * ¿Por qué es peligroso?
     * Al no utilizar parámetros seguros, un atacante puede ingresar un payload 
     * como 'admin' --' para comentar el resto de la consulta (la validación de la 
     * contraseña), logrando iniciar sesión sin autorización.
     * 
     * Reto: Refactoriza el método usando Spring Data JPA (por ejemplo, findByUsername) 
     * y un PasswordEncoder para validar el hash de forma segura.
     */
    @SuppressWarnings("unchecked")
    public List<User> loginInseguro(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = '" + username
                   + "' AND password = '" + password + "'";
        return entityManager.createNativeQuery(sql, User.class).getResultList();
    }

    /**
     * Implemente su solución aquí
     */
}
