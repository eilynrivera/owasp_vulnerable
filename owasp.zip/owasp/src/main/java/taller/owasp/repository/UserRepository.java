package taller.owasp.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import taller.owasp.domain.User;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);
}
