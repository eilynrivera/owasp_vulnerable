package taller.owasp.shared;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@Profile("vulnerable")
public class DashboardController {

    private static final Path ARCHIVO = Path.of("scoreboard.jsonl");

    private final ObjectMapper objectMapper;

    public DashboardController(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @GetMapping("/dashboard")
    public List<ResultadoDashboard> obtenerDashboard() throws IOException {

        Map<String, ResultadoDashboard> resultados = new LinkedHashMap<>();

        if (!Files.exists(ARCHIVO)) {
            return List.of();
        }

        List<String> registros = Files.readAllLines(
                ARCHIVO, StandardCharsets.UTF_8
        );

        for (String registro : registros) {

            if (registro.isBlank()) {
                continue;
            }

            JsonNode datos;

            try {
                datos = objectMapper.readTree(registro);
            } catch (JsonProcessingException e) {
                throw new IllegalStateException(
                        "Registro inválido en scoreboard.jsonl.", e
                );
            }

            String modulo = datos.path("modulo").asText();
            String ataque = datos.path("ataque").asText();
            String resultado = datos.path("resultado").asText();

            if (AtaquesInyeccion.EXITO.equals(resultado)) {
                resultados.putIfAbsent(
                        modulo + "|" + ataque,
                        new ResultadoDashboard(modulo, ataque, resultado)
                );
            }
        }

        return new ArrayList<>(resultados.values());
    }

    public record ResultadoDashboard(
            String modulo,
            String ataque,
            String vulnerable
    ) {}
}
