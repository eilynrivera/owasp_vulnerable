package taller.owasp.shared;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import taller.owasp.domain.User;
import taller.owasp.repository.UserRepository;

/**
 * Carga de usuarios de prueba. Las contrasenas se guardan EN CLARO, a proposito (M2).
 */
@Component
public class UserSeed {

    private final UserRepository userRepository;
    private final PasswordEncoder encoder;

    public UserSeed(UserRepository userRepository, PasswordEncoder encoder) {
        this.userRepository = userRepository;
        this.encoder = encoder;
    }

    /**
     * =========================================================================
     * Ejercicio 1. Login (paso previo): guardar las contraseñas con hash
     * =========================================================================
     * Inserta los usuarios de prueba en la base de datos al arrancar el servidor.
     * Primero borra los existentes y luego guarda cada usuario con su nombre,
     * su contraseña y su rol.
     *
     * ATENCIÓN (Vulnerabilidad de exposición de datos sensibles):
     * Las contraseñas se guardan en texto plano, tal como las escribió el usuario:
     *     new User("admin", "admin123", null, "ADMIN")
     *
     * ¿Por qué es peligroso?
     * Cualquiera que logre leer la tabla de usuarios (por ejemplo, con la
     * inyección SQL del buscador o desde la consola H2) obtiene directamente las
     * contraseñas reales. Como muchas personas reutilizan sus contraseñas, el
     * atacante también podría entrar a otras cuentas de la víctima.
     *
     * Reto:
     * Inyecta el bean PasswordEncoder (definido en PasswordConfig) en esta clase
     * y úsalo para guardar el hash de cada contraseña en lugar del texto plano.
     * Este paso es necesario para el login seguro del Ejercicio 1: BCrypt compara
     * la contraseña ingresada contra un hash, así que si la base guarda texto
     * plano, ningún usuario podrá iniciar sesión.
     */
    public void inicializarVulnerable() {
        userRepository.deleteAll();
        userRepository.save(new User("admin", "admin123", null, "ADMIN"));
        userRepository.save(new User("maria", "sunshine", null, "USER"));
        userRepository.save(new User("juan", "qwerty2024", null, "USER"));
    }
}
